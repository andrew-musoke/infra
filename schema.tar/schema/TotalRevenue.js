cube(`TotalRevenue`, {
    extends: DubaivisatotalrevenueDev,
  });