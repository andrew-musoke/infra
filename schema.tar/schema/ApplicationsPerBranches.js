cube(`ApplicationsPerBranches`, {
    extends: DubaivisaapplicationsperbranchesDev,
  });