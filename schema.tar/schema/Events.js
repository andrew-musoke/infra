cube(`Events`, {
    extends: BasesmsauthcolumnsReal,
  });