cube(`Events`, {
    extends: Basesmsauthcolumns1Real,
  });