cube(`RejectedCountry`, {
    extends: DubaivisarejectedpercountryDev,
  });