cube(`VisaRequestsDetails`, {
    extends: DubaivisarequestsdetailsDev,
  });