cube(`ApplicantsCountry`, {
    extends: DubaivisaapplicantspercountryDev,
  });
  