cube(`Smsbalance`, {
    extends: Smsbalance4Real,
  });