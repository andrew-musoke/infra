cube(`Smsbalance`, {
    extends: SmsbalanceReal,
  });