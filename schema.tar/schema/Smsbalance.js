cube(`Smsbalance`, {
    extends: Smsbalance3Real,
  });