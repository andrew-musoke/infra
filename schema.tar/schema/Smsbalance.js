cube(`Smsbalance`, {
    extends: Smsbalance2Real,
  });