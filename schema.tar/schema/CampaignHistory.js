cube(`CampaignHistory`, {
    extends: Campaignhistoryrealv1,
  });