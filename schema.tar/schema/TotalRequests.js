cube(`TotalRequests`, {
    extends: DubaivisatotalrequestsDev,
  });