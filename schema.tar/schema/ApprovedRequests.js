cube(`ApprovedRequests`, {
    extends: DubaivisaapprovedrequestsDev,
  });