cube(`EventsMain`, {
    extends: Events,
  });