cube(`VisatypePerApplicants`, {
    extends: DubaivisatypeperapplicationDev,
  });