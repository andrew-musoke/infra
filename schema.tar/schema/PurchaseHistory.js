cube(`PurchaseHistory`, {
    extends: Purchasehistoryreal,
    //extends: PurchasehistoryrealV2,
  });