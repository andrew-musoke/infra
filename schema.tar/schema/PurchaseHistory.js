cube(`PurchaseHistory`, {
    extends: Purchasehistoryrealv1,
  });