cube(`PurchaseHistory`, {
    extends: PurchasehistoryrealV2,
  });