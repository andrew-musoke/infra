cube(`RevenuePerBranches`, {
    extends: DubaivisarevenueperbranchesDev,
  });