cube(`Activities`, {
    extends: Basesmsactivitiesreal,
  });