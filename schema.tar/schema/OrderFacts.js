cube(`OrderFacts`, {
    extends: Orders,
  });
  