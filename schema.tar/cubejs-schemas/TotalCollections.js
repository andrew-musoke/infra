// DESCRIPTION
// This schema used to show Collections data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 4: Total Collections - a big number showing the total amount of Collections made on a wallet.
// Number 7: Collections Trends - a line chart trend showing collections per specific time.


cube(`TotalCollections`, {

    sql: `
          SELECT WALLETID, SUM(AMOUNT) AS TOTALCOLLECTIONS, TIMESTAMP
          FROM paymentsdomain_staging.wallettransactions
          WHERE TRANSACTIONTYPE='COLLECTION' AND STATUS='SUCCESS' 
          GROUP BY  WALLETID, TIMESTAMP
          `,
         
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
        Walletsinfo: {
        relationship: `belongsTo`,
        sql: `${CUBE}.WALLETID = ${Walletsinfo}.WALLETID`,
      }   
    },
    
    measures: {
      count: {
        type: `count`,
         },
   
      totalcollectionsNumber: {
          sql:`TOTALCOLLECTIONS`,
          type: `sum`,
           },
  
    },
    
    dimensions: {
      walletid: {
        sql: `${CUBE}."WALLETID"`,
        type: `string`,
        primaryKey: true,
        shown: true
      },
  
      customerid: {
        sql: `${Walletsinfo}."CUSTOMERID"`,
        type: `string`
      },
  
      amount: {
        sql: `${CUBE}."TOTALCOLLECTIONS"`,
        type: `number`
      },
      
      timestamp: {
        sql: `${CUBE}."TIMESTAMP"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  