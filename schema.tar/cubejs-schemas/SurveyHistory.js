// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Surveyhistoryreal features
// This is done purposely to decouple the PurchaseHistory table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 19: Survey History - containing a list of surveys and their details.

cube(`SurveyHistory`, {
    extends: Surveyhistoryreal,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  

      main: {
        measures: [SurveyHistory.count],
        dimensions: [SurveyHistory.trackid, SurveyHistory.surveyid, SurveyHistory.customerid, SurveyHistory.appid, SurveyHistory.status, SurveyHistory.eventtype, SurveyHistory.surveyname, SurveyHistory.surveydescription, SurveyHistory.primaryShortCode, SurveyHistory.secondaryShortCode, SurveyHistory.createdAt, SurveyHistory.startDate, SurveyHistory.endDate],
        timeDimension: SurveyHistory.updatedAt,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [SurveyHistory.trackid, SurveyHistory.surveyid, SurveyHistory.customerid, SurveyHistory.appid, SurveyHistory.status, SurveyHistory.eventtype, SurveyHistory.surveyname, SurveyHistory.surveydescription, SurveyHistory.primaryShortCode, SurveyHistory.secondaryShortCode, SurveyHistory.createdAt, SurveyHistory.startDate, SurveyHistory.endDate] 
          }
        }
      }
    },
  });