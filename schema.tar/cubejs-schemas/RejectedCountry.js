// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the dubaivisarejectedpercountry_dev table features
// This is done purposely to decouple the dubaivisarejectedpercountry_dev table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 7: Rejected Applications Per Branches

cube(`RejectedCountry`, {
    extends: DubaivisarejectedpercountryDev,
  });