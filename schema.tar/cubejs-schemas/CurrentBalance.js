// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Walletsinfo features
// This is done purposely to decouple the Walletsinfo stream to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 2: Wallet's current balance - a big number showing wallet's current balance.

cube(`CurrentBalance`, {
    extends: Walletsinfo,
  });