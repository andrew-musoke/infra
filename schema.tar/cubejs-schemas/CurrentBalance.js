// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Walletsinfo features
// This is done purposely to decouple the Walletsinfo stream to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 2: Wallet's current balance - a big number showing wallet's current balance.

cube(`CurrentBalance`, {
    extends: Walletsinfo,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  

      main: {
        dimensions: [CurrentBalance.walletid, CurrentBalance.customerid, CurrentBalance.label, CurrentBalance.actualbalance, CurrentBalance.availablebalance, CurrentBalance.customername, CurrentBalance.currencyid, CurrentBalance.createdAt],
        timeDimension: CurrentBalance.updatedAt,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [CurrentBalance.walletid, CurrentBalance.customerid, CurrentBalance.label, CurrentBalance.actualbalance, CurrentBalance.availablebalance, CurrentBalance.customername, CurrentBalance.currencyid, CurrentBalance.createdAt] 
          }
        }
      }
    }
  });