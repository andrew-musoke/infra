// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Bounceratereal features
// This is done purposely to decouple the BounceRate table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 8: Bounce Rate - shows the percentage of the single menu item visit divided by all visits.

cube(`BounceRate`, {
    extends: Bounceratereal,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      main: {
        dimensions: [BounceRate.customerid, BounceRate.appid, BounceRate.bouncerate, BounceRate.totalsessionsended],
        indexes: {
          categoryIndex: {
           columns: [BounceRate.customerid, BounceRate.appid, BounceRate.bouncerate, BounceRate.totalsessionsended] 
          }
        }
      }
  
    },
  });