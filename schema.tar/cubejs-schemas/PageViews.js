// DESCRIPTION
// This schema calculates the page views for the ussd applications.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 14: Page Views - describes a total number of time a ussd page (sequence) was visited by a user
// Number 16: Pageviews per session - average number of ussd pages visited per one distinct session


cube(`PageViews`, {
    sql: ` SELECT SESSIONID, SERVICECODE, MAX(SEQUENCE) AS SEQ, PHONENUMBER, APPID, CUSTOMERID, MAX(TIME) AS TIMESTAMP
           FROM ussddomain.sessionhistoryreal
           GROUP BY SESSIONID, SERVICECODE, PHONENUMBER, APPID, CUSTOMERID`,

        
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  

      main: {
        //measures: [PageViews.count, PageViews.pageViewCount, PageViews.pageViewsperSession],
        dimensions: [PageViews.sessionid, PageViews.customerid, PageViews.servicecode, PageViews.sequence, PageViews.phonenumber, PageViews.appid],
        timeDimension: PageViews.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [PageViews.sessionid, PageViews.customerid, PageViews.servicecode, PageViews.sequence, PageViews.phonenumber, PageViews.appid] 
          }
        }
      }
    },
    
    joins: {
      
    },
    
    measures: {
      count: {
        sql:`SESSIONID`,
        type: `countDistinct`,
      },

      pageViewCount: {
        sql:`SEQ`,
        type: `sum`,
      },

      pageViewsperSession: {
        sql:`${CUBE.pageViewCount}/${CUBE.count}`,
        type: `number`,
      }

    },
    
    dimensions: {
     
      sessionid: {
        sql: `${CUBE}."SESSIONID"`,
        type: `string`,
        primaryKey: true,
        shown: true,
      },
      
      servicecode: {
        sql: `${CUBE}."SERVICECODE"`,
        type: `string`
      },
      
      sequence: {
        sql: `${CUBE}."SEQ"`,
        type: `number`
      },

      phonenumber: {
        sql: `${CUBE}."PHONENUMBER"`,
        type: `string`
      },
      
      appid: {
        sql: `${CUBE}."APPID"`,
        type: `string`,
      },

      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
  
      timestamp: {
        sql: `${CUBE}."TIMESTAMP"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  