// DESCRIPTION
// This schema used to model raw campaign-history data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 2: SMS Campaign History - containing a detailed description and analytics of the campaign sent
// Number 9: Total Campaigns - contains a total number of campaigns launched per customer


cube(`Campaigndetails`, {
    sql: `SELECT * FROM smsdomain_staging.campaigndetails`,

    refreshKey: {
        every: `1 second`,
      },
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
      
    },
    
    measures: {
      count: {
        type: `count`,
        drillMembers: [customerid, campaignid, campaignname, timestamp]
      }
    },
    
    dimensions: {
      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
      
      campaignid: {
        sql: `${CUBE}."CAMPAIGNID"`,
        type: `string`
      },
      
      campaignname: {
        sql: `${CUBE}."CAMPAIGNNAME"`,
        type: `string`
      },
    
      numberofrecipients: {
        sql: `${CUBE}."TOTALRECIPIENTS"`,
        type: `number`
      },
  
      mtnNumbers: {
        sql: `${CUBE}."MTNSUCCESS"`,
        type: `number`
      },
  
      airtelNumbers: {
        sql: `${CUBE}."AIRTELSUCCESS"`,
        type: `number`
      },
  
      totalSuccessStatus: {
        sql: `${CUBE}."TOTAL_SUCCESS_STATUS"`,
        type: `number`
      },
  
      totalFailedStatus: {
        sql: `${CUBE}."TOTAL_FAILED_STATUS"`,
        type: `number`
      },
  
      deliveryrate: {
        sql: `${CUBE}."DELIVERYRATE"`,
        type: `number`
      },
      
      status: {
        sql: `${CUBE}."STATUS"`,
        type: `string`
      },
      
      timestamp: {
        sql: `${CUBE}."TIMESTAMP"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  