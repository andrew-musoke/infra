// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Userinforeal features
// This is done purposely to decouple the UserInfo table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 5: User Info Table- containing a detailed information about a baseussd users.

cube(`UserInfo`, {
    extends: Userinforeal
  });