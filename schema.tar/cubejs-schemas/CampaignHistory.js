// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Campaignhistoryreal features
// This is done purposely to decouple the CampaignHistory table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 2: SMS Campaign History - containing a detailed description and analytics of the campaign sent


cube(`CampaignHistory`, {
    extends: Campaigndetails,
  });