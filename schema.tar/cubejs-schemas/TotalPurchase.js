// DESCRIPTION
// This schema uses purchase history table to calculate the total purchases
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 2: Total Purchase - describes total purchase made on the buim ussd app


cube(`TotalPurchase`, {
    sql: `SELECT * FROM energydomain.purchasehistory`,
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
      
    },
    
    measures: {
      totalpurchase: {
        sql: `AMOUNTPAID`,
        type: `sum`,
      }
    },
    
    dimensions: {

      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
        
      timestamp: {
        sql: `${CUBE}."TIME"`,
        type: `time`
      }
    },
    
    segments: {
        purchaseStatus: {
          sql: `${CUBE}.STATUS = 'SUCCESS'`,
        },
      },
    dataSource: `default`
  });
  