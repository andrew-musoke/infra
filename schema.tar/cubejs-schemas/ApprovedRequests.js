// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the dubaivisaapprovedrequests_dev table features
// This is done purposely to decouple the dubaivisaapprovedrequests_dev table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 2: Total number of approved applications

cube(`ApprovedRequests`, {
    extends: DubaivisaapprovedrequestsDev,
  });