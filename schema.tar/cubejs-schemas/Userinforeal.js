// DESCRIPTION
// This schema used to model raw appinfo data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 5: User Info Table- containing a detailed information about a baseussd users.


cube(`Userinforeal`, {
  sql: `SELECT * FROM ussddomain.userinfo`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      sql:'CUSTOMERID',
      type: `countDistinct`,
      drillMembers: [customerid, customername, firstname, lastname]
    }
  },
  
  dimensions: {
    baseservice: {
      sql: `${CUBE}."BASESERVICE"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },
    
    customername: {
      sql: `${CUBE}."CUSTOMERNAME"`,
      type: `string`
    },
    
    email: {
      sql: `${CUBE}."EMAIL"`,
      type: `string`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    firstname: {
      sql: `${CUBE}."FIRSTNAME"`,
      type: `string`
    },
    
    lastname: {
      sql: `${CUBE}."LASTNAME"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
