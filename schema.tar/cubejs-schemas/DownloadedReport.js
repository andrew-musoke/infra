// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Downloadedreportsreal features
// This is done purposely to decouple the Downloadedreportsreal stream to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 8: Downloaded reports - a table that contains a list of all downloaded reports transactions made by a specific customer.


cube(`DownloadedReport`, {
    extends: Downloadedreportsreal,
  });