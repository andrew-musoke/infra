// DESCRIPTION
// This schema used to model applicants per country data from the clickhouse database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 10: Applicants geographic distribution

cube(`Dubaivisaapplicantspercountry`, {
  sql: `SELECT * FROM dubaivisadomain.dubaivisaapplicantspercountry`,

  refreshKey: {
    every: `1 second`,
  },
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [country, timestamp]
    }
  },
  
  dimensions: {
    country: {
      sql: `${CUBE}."COUNTRY"`,
      type: `string`
    },

    applicants: {
      sql: `${CUBE}."COUNT_NATIONALITY"`,
      type: `number`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
