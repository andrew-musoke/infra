// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Payment requests features
// This is done purposely to decouple the Paymentrequests stream to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 10: Payment Requests - contains a list of all payment requests made to the wallet.


cube(`BulkPaymentMeta`, {
    extends: Paymentrequests,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      main: {
        dimensions: [BulkPaymentMeta.paymentdescription, BulkPaymentMeta.actorcustomerid,  BulkPaymentMeta.trackid, BulkPaymentMeta.merchanttransactionid, BulkPaymentMeta.status,  BulkPaymentMeta.statusdescription, BulkPaymentMeta.totalbeneficiaries,  BulkPaymentMeta.totalamount],
        timeDimension: BulkPaymentMeta.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [BulkPaymentMeta.paymentdescription, BulkPaymentMeta.actorcustomerid,  BulkPaymentMeta.trackid, BulkPaymentMeta.merchanttransactionid, BulkPaymentMeta.status,  BulkPaymentMeta.statusdescription, BulkPaymentMeta.totalbeneficiaries,  BulkPaymentMeta.totalamount] 
          }
        }
      }
  
    }
  });