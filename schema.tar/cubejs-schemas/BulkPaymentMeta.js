// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Payment requests features
// This is done purposely to decouple the Paymentrequests stream to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 10: Payment Requests - contains a list of all payment requests made to the wallet.


cube(`BulkPaymentMeta`, {
    extends: Paymentrequests,
  });