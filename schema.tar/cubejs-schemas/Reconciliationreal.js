// DESCRIPTION
// This schema used to model raw transactions data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 18: Reconciliation Table - contains a record of all the transactions made (purchases & sessions_charged)


cube(`Reconciliationreal`, {
  sql: `SELECT * FROM ussddomain.reconciliation`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      sql: `TRACKID`,
      type: `countDistinct`,
    },
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },
    
    transactiontype: {
      sql: `${CUBE}."TRANSACTIONTYPE"`,
      type: `string`
    },
    
    eventtype: {
      sql: `${CUBE}."EVENTTYPE"`,
      type: `string`
    },

    amount: {
      sql: `${CUBE}."AMOUNT"`,
      type: `number`
    },

    sessions: {
      sql: `${CUBE}."SESSIONS"`,
      type: `number`
    },

    currentbalance: {
      sql: `${CUBE}."CURRENTBALANCE"`,
      type: `number`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
