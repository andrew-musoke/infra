// DESCRIPTION
// This schema used to model raw charged-sessions data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 11: Charged Sessions - containing information about charged session.


cube(`Chargedsessionsreal`, {
  sql: `SELECT * FROM ussddomain.chargedsessions`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [sessionid, trackid, appid, customerid]
    }
  },
  
  dimensions: {
    sessionid: {
      sql: `${CUBE}."SESSIONID"`,
      type: `string`,
      primaryKey: true,
      shown: true,
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    menuitem: {
      sql: `${CUBE}."MENUITEM"`,
      type: `string`
    },
    
    sequence: {
      sql: `${CUBE}."SEQUENCE"`,
      type: `number`,
      primaryKey: true,
      shown: true,
    },

    chargedamount: {
      sql: `${CUBE}."CHARGEDAMOUNT"`,
      type: `number`
    },

    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    telco: {
      sql: `${CUBE}."TELCO"`,
      type: `string`
    },
    
    appid: {
      sql: `${CUBE}."APPID"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
