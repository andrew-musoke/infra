// DESCRIPTION
// This schema used to model total number of approved applications data from the clickhouse database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 2: Total number of approved applications

cube(`DubaivisaapprovedrequestsDev`, {
  sql: `SELECT * FROM dubaivisadomain_dev.dubaivisaapprovedrequests_dev`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [timestamp]
    }
  },
  
  dimensions: {
    applicationstatus: {
      sql: `${CUBE}."APPLICATIONSTATUS"`,
      type: `string`
    },
    
    totalApproved: {
      sql: `${CUBE}."APPROVED_APPLICATIONS"`,
      type: `number`
    },

    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
