// DESCRIPTION
// This schema used to model revenue per branches data from the clickhouse database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 5: Revenue per branches


cube(`DubaivisarevenueperbranchesDev`, {
  sql: `SELECT * FROM dubaivisadomain_dev.dubaivisarevenueperbranches_dev`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [branchname, timestamp]
    }
  },
  
  dimensions: {
    branchname: {
      sql: `${CUBE}."BRANCHNAME"`,
      type: `string`
    }, 

    revenue: {
      sql: `${CUBE}."REVENUE"`,
      type: `number`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
