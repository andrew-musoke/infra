// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Activitiesreal features
// This is done purposely to decouple the Activities table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 12: Activity Page - contains a combination of events (i.e. authorization, purchase,etc) in the baseussd application.

cube(`Activities`, {
    extends: Activitiesreal,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      main: {
        measures: [Activities.count],
        dimensions: [Activities.customerid, Activities.category, Activities.eventtype, Activities.username, Activities.verb, Activities.indirectobject, Activities.directobject],
        timeDimension: Activities.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [Activities.customerid, Activities.category, Activities.eventtype, Activities.username, Activities.verb, Activities.indirectobject, Activities.directobject] 
          }
        }
      }
  
    },
  });