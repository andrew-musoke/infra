// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Activitiesreal features
// This is done purposely to decouple the Activities table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 12: Activity Page - contains a combination of events (i.e. authorization, purchase,etc) in the baseussd application.

cube(`Activities`, {
    extends: Activitiesreal
  });