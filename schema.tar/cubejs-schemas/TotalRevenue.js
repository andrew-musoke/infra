// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the dubaivisatotalrevenue_dev features
// This is done purposely to decouple the dubaivisatotalrevenue_dev table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 3: Total revenue

cube(`TotalRevenue`, {
    extends: DubaivisatotalrevenueDev,
  });