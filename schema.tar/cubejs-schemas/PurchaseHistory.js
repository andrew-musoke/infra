// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Purchasehistoryreal features
// This is done purposely to decouple the PurchaseHistory table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 1: Purchase History - containing a details of purchases made


cube(`PurchaseHistory`, {
    extends: Purchasehistoryreal,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      main: {
        measures: [PurchaseHistory.count],
        dimensions: [PurchaseHistory.customerid, PurchaseHistory.status, PurchaseHistory.amountPaid, PurchaseHistory.numberAllocated, PurchaseHistory.phonenumber, PurchaseHistory.description, PurchaseHistory.telco, PurchaseHistory.purchaseType],
        timeDimension: PurchaseHistory.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [PurchaseHistory.customerid, PurchaseHistory.status, PurchaseHistory.amountPaid, PurchaseHistory.numberAllocated, PurchaseHistory.phonenumber, PurchaseHistory.description, PurchaseHistory.telco, PurchaseHistory.purchaseType] 
          }
        }
      }
  
    },
  });