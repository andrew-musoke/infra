// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Purchasehistoryreal features
// This is done purposely to decouple the PurchaseHistory table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 1: Purchase History - containing a details of purchases made


cube(`PurchaseHistory`, {
    extends: Purchasehistoryreal
  });