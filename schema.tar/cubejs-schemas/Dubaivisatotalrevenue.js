// DESCRIPTION
// This schema used to model Total revenue data from the clickhouse database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 3: Total revenue

cube(`Dubaivisatotalrevenue`, {
  sql: `SELECT * FROM dubaivisadomain_staging.dubaivisatotalrevenue`,

  refreshKey: {
    every: `1 second`,
  },

  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [timestamp]
    }
  },
  
  dimensions: {

    revenue: {
      sql: `${CUBE}."TOTALREVENUE"`,
      type: `number`
    },

    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
