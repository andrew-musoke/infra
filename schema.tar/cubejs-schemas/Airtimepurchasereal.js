// DESCRIPTION
// This schema used to model airtime purchase-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 8: Airtime Purchases - shows all airtime purchases

cube(`Airtimepurchasereal`, {
  sql: `SELECT * FROM energydomain_staging_staging.airtimepurchase`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      sql: `${CUBE}."TRACKID"`,
      type: `countDistinct`,
    },
    
    totalamount: {
      sql: `${CUBE}."AMOUNT"`,
      type: `sum`
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },
    
    purchasedescription: {
      sql: `${CUBE}."PURCHASEDESCRIPTION"`,
      type: `string`
    },
    
    payerphonenumber: {
      sql: `${CUBE}."PAYERPHONENUMBER"`,
      type: `string`
    },
    
    recipientphonenumber: {
      sql: `${CUBE}."RECIPIENTPHONENUMBER"`,
      type: `string`
    },

    amount: {
      sql: `${CUBE}."AMOUNT"`,
      type: `number`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },
    
    statusdescription: {
      sql: `${CUBE}."STATUSDESCRIPTION"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});