// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Payment requests features

// REQUIREMENT
// Number 11: Bulk transactions - contains a list of all bulk transactions processed by the wallet.


cube(`BulkPaymentTransactions`, {
    sql: `SELECT * FROM paymentsdomain.wallettransactions
        WHERE PAYMENTTYPE='BULK_PAYMENT'`,
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started 
      
      main: {
        dimensions: [BulkPaymentTransactions.trackid, BulkPaymentTransactions.transactionid, BulkPaymentTransactions.walletid, BulkPaymentTransactions.amount, BulkPaymentTransactions.accountto,   BulkPaymentTransactions.status,  BulkPaymentTransactions.description],
        timeDimension: BulkPaymentTransactions.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [BulkPaymentTransactions.trackid, BulkPaymentTransactions.transactionid, BulkPaymentTransactions.walletid, BulkPaymentTransactions.amount, BulkPaymentTransactions.accountto,   BulkPaymentTransactions.status,  BulkPaymentTransactions.description] 
          }
        }
      }
    },
    
    joins: {
      
    },
    
    measures: {
      count: {
        type: `count`,
        //drillMembers: [transactionid, walletid, trackid, paymentprovidertransactionid, paymentprovider, submerchanttransactionid, payeefirstname, payeelastname, actorcustomerid, actorcustomername, timestamp]
      }
    },
    
    dimensions: {
      transactionid: {
        sql: `${CUBE}."TRANSACTIONID"`,
        type: `string`
      },
      
      walletid: {
        sql: `${CUBE}."WALLETID"`,
        type: `string`
      },
      
      operation: {
        sql: `${CUBE}."OPERATION"`,
        type: `string`
      },
      
      transactiontype: {
        sql: `${CUBE}."TRANSACTIONTYPE"`,
        type: `string`
      },
      
      amount: {
        sql: `${CUBE}."AMOUNT"`,
        type: `number`
      },
      
      runningbalance: {
        sql: `${CUBE}."RUNNINGBALANCE"`,
        type: `number`
      },
  
      fee: {
        sql: `${CUBE}."FEE"`,
        type: `number`
      }, 
  
      amountbefore: {
        sql: `${CUBE}."AMOUNTBEFORE"`,
        type: `number`
      },
  
      currency: {
        sql: `${CUBE}."CURRENCY"`,
        type: `string`
      },
      
      trackid: {
        sql: `${CUBE}."TRACKID"`,
        type: `string`
      },
      
      accountfrom: {
        sql: `${CUBE}."ACCOUNTFROM"`,
        type: `string`
      },
      
      accountfromtype: {
        sql: `${CUBE}."ACCOUNTFROMTYPE"`,
        type: `string`
      },
      
      accountto: {
        sql: `${CUBE}."ACCOUNTTO"`,
        type: `string`
      },
      
      accounttotype: {
        sql: `${CUBE}."ACCOUNTTOTYPE"`,
        type: `string`
      },
      
      paymentprovidertransactionid: {
        sql: `${CUBE}."PAYMENTPROVIDERTRANSACTIONID"`,
        type: `string`
      },
      
      paymentprovider: {
        sql: `${CUBE}."PAYMENTPROVIDER"`,
        type: `string`
      },
      
      submerchanttransactionid: {
        sql: `${CUBE}."SUBMERCHANTTRANSACTIONID"`,
        type: `string`
      },
      
      description: {
        sql: `${CUBE}."DESCRIPTION"`,
        type: `string`
      },
      
      status: {
        sql: `${CUBE}."STATUS"`,
        type: `string`
      },
      
      callback: {
        sql: `${CUBE}."CALLBACK"`,
        type: `string`
      },
      
      paymenttype: {
        sql: `${CUBE}."PAYMENTTYPE"`,
        type: `string`
      },
      
      payeefirstname: {
        sql: `${CUBE}."PAYEEFIRSTNAME"`,
        type: `string`
      },
      
      payeelastname: {
        sql: `${CUBE}."PAYEELASTNAME"`,
        type: `string`
      },
      
      actorcustomerid: {
        sql: `${CUBE}."ACTORCUSTOMERID"`,
        type: `string`
      },
      
      actorcustomername: {
        sql: `${CUBE}."ACTORCUSTOMERNAME"`,
        type: `string`
      },
      
      timestamp: {
        sql: `${CUBE}."TIMESTAMP"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  