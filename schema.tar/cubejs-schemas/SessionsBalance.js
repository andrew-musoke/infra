// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Sessionsbalancereal features
// This is done purposely to decouple the SessionsBalance table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 4: Sessions Balance Table - contains information about remaining sessions balance in clients wallets.

cube(`SessionsBalance`, {
    extends: Sessionsbalancereal,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      main: {
        //measures: [SessionsBalance.count],
        dimensions: [SessionsBalance.trackid, SessionsBalance.customerid, SessionsBalance.balance],
        timeDimension: SessionsBalance.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [SessionsBalance.trackid, SessionsBalance.customerid, SessionsBalance.balance] 
          }
        }
      }
  
    },
  });