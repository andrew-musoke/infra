// DESCRIPTION
// This schema used to model visa application details data from the clickhouse database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 10: Visas Requests-Drill Down (i.e. Status, VisaType, Applicant Names, Email, Phone, Branch Name, Town, Country, Application Date)

cube(`Dubaivisarequestsdetails`, {
  sql: `SELECT * FROM dubaivisadomain.dubaivisarequestsdetails`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },

  refreshKey: {
    every: `1 second`,
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [referenceid, firstname, lastname, timestamp]
    }
  },
  
  dimensions: {
    referenceid: {
      sql: `${CUBE}."REFERENCEID"`,
      type: `string`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },
    
    visatype: {
      sql: `${CUBE}."VISATYPE"`,
      type: `string`
    },
    
    firstname: {
      sql: `${CUBE}."FIRSTNAME"`,
      type: `string`
    },
    
    lastname: {
      sql: `${CUBE}."LASTNAME"`,
      type: `string`
    },
    
    applicantsEmail: {
      sql: `${CUBE}."APPLICANTS_EMAIL"`,
      type: `string`
    },
    
    phoneNumber: {
      sql: `${CUBE}."PHONE_NUMBER"`,
      type: `string`
    },
    
    applicantsNationality: {
      sql: `${CUBE}."APPLICANTS_NATIONALITY"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
