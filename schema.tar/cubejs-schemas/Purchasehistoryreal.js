// DESCRIPTION
// This schema used to model raw purchase-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 1: Purchase History - containing a report on the purchases made from the buim ussd app


cube(`Purchasehistoryreal`, {
  sql: `SELECT * FROM energydomain.purchasehistory`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      sql: `TRANSACTIONID`,
      type: `countDistinct`,
      //drillMembers: [trackid, customerid, transactionid, sessionid]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },

    customername: {
      sql: `${CUBE}."CUSTOMERNAME"`,
      type: `string`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },

    amountpaid: {
      sql: `${CUBE}."AMOUNTPAID"`,
      type: `number`
    },
    
    telco: {
      sql: `${CUBE}."TELCO"`,
      type: `string`
    },
    
    accountno: {
      sql: `${CUBE}."ACCOUNTNO"`,
      type: `string`
    },
    
    transactionid: {
      sql: `${CUBE}."TRANSACTIONID"`,
      type: `string`
    },
    
    sessionid: {
      sql: `${CUBE}."SESSIONID"`,
      type: `string`
    },

    producttype: {
      sql: `${CUBE}."PRODUCTTYPE"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
