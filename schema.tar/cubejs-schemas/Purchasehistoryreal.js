// DESCRIPTION
// This schema used to model raw purchase-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 1: Purchase History - containing a details of purchases made


cube(`Purchasehistoryreal`, {
  sql: `SELECT * FROM ussddomain.purchasehistoryreal`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [trackid, customerid]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },

    amountPaid: {
      sql: `${CUBE}."AMOUNTPAID"`,
      type: `number`
    },

    sessionsAllocated: {
      sql: `${CUBE}."SESSIONSALLOCATED"`,
      type: `number`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    telco: {
      sql: `${CUBE}."TELCO"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
