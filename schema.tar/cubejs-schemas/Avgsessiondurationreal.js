// DESCRIPTION
// This schema used to model raw purchase-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 6: Average Session Duration- containing information about the average session duration.


cube(`Avgsessiondurationreal`, {
  sql: `SELECT CUSTOMER_ID, AVG(MAX_SESSIONDURATION) AS AVG_SESSIONDURATION
        FROM ussddomain_staging.maxsessionduration
        GROUP BY CUSTOMER_ID`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      //drillMembers: [customerId, timestamp]
    },
    
  },
  
  dimensions: {
    customerid: {
      sql: `${CUBE}."CUSTOMER_ID"`,
      type: `string`
    },
    
    // sessionId: {
    //   sql: `${CUBE}."SESSION_ID"`,
    //   type: `string`
    // },

    avgsessionduration: {
      sql: `${CUBE}."AVG_SESSIONDURATION"`,
      type: `number`
    },
    
    // appId: {
    //   sql: `${CUBE}."APP_ID"`,
    //   type: `string`
    // },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
