// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the dubaivisaapplicantspercountry_dev features
// This is done purposely to decouple the dubaivisaapplicantspercountry_dev table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 10: Applicants geographic distribution

cube(`ApplicantsPerCountry`, {
    extends: Dubaivisaapplicantspercountry,
  });
  