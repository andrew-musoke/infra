// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Appinforeal features
// This is done purposely to decouple the AppInfo table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 3: App Info Table - containing a detailed information about a ussd applications.

cube(`AppInfo`, {
    extends: Appinforeal,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      //main: {
       // measures: [AppInfo.count],
       // dimensions: [AppInfo.customerid, AppInfo.appid, AppInfo.appname, AppInfo.primaryshortcode, AppInfo.secondaryshortcode, AppInfo.url, AppInfo.telcos, AppInfo.type, AppInfo.active, AppInfo.creationDate],
       // timeDimension: AppInfo.updatedDate,
       // granularity: `day`,
       // indexes: {
       //   categoryIndex: {
        //   columns: [AppInfo.customerid, AppInfo.appid, AppInfo.appname, AppInfo.primaryshortcode, AppInfo.secondaryshortcode, AppInfo.url, AppInfo.telcos, AppInfo.type, AppInfo.active, AppInfo.creationDate] 
        //  }
       // }
   //   }
  
    },
  });