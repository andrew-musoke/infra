// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Appinforeal features
// This is done purposely to decouple the AppInfo table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 3: App Info Table - containing a detailed information about a ussd applications.

cube(`AppInfo`, {
    extends: Appinforeal
  });