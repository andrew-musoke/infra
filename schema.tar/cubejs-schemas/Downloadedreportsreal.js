// DESCRIPTION
// This schema used to show a list of downloaded reports data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 8: Downloaded reports - a table that contains a list of all downloaded reports transactions made by a specific customer.

cube(`Downloadedreportsreal`, {
  sql: `SELECT * FROM paymentsdomain_staging.downloadedreports`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      sql:`REPORTID`,
      type: `countDistinct`,
      //drillMembers: [reportid, walletid, customerid, daterange]
    }
  },
  
  dimensions: {
    reportid: {
      sql: `${CUBE}."REPORTID"`,
      type: `string`
    },
    
    walletid: {
      sql: `${CUBE}."WALLETID"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },
    
    daterange: {
      sql: `${CUBE}."DATERANGE"`,
      type: `string`
    },
    
    deliveredto: {
      sql: `${CUBE}."EMAILS"`,
      type: `string`
    },
    
    eventtype: {
      sql: `${CUBE}."EVENTTYPE"`,
      type: `string`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },
    
    link: {
      sql: `${CUBE}."DOWNLOADLINK"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
