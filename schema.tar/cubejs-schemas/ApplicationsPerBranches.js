// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the dubaivisaapplicationsperbranches_dev table features
// This is done purposely to decouple the dubaivisaapplicationsperbranches_dev table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 4: Visa applications per branches

cube(`ApplicationsPerBranches`, {
    extends: Dubaivisaapplicationsperbranches,
  });