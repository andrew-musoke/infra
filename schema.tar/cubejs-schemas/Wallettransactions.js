// DESCRIPTION
// This schema used to model transactions history data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 1: Transactions History - a table that contains all transactions made on a specific wallet.
// Number 3: Total Payouts - a big number showing the total amount of Payouts made on a wallet.
// Number 6: Payout Trends - a line chart trend showing payouts per specific time.
// Number 4: Total Collections - a big number showing the total amount of Collections made on a wallet.
// Number 7: Collections Trends - a line chart trend showing collections per specific time.
// Number 5: Total Payouts & Collections - a big number showing the total amount of Payouts & Collections made on a wallet.


cube(`Wallettransactions`, {
  sql: `SELECT * FROM paymentsdomain_staging.wallettransactions`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `countDistinct`,
      sql: `${CUBE}."TRANSACTIONID"`,
       },

    totalcollections: {
      type: `sum`,
      sql: `${CUBE}."AMOUNT"`,
      filters: [{ sql: `${CUBE}.STATUS = 'SUCCESS' AND ${CUBE}.TRANSACTIONTYPE='COLLECTION'` }],
       },


    totalpayouts: {
      type: `sum`,
      sql: `${CUBE}."AMOUNT"`,
      filters: [{ sql: `${CUBE}.STATUS = 'SUCCESS' AND ${CUBE}.TRANSACTIONTYPE='PAYOUT'` }],
         },

    totalcollectionspayouts: {
      type: `sum`,
      sql: `${CUBE}."AMOUNT"`,
      filters: [{ sql: `(${CUBE}.STATUS = 'SUCCESS' AND ${CUBE}.TRANSACTIONTYPE='PAYOUT') OR (${CUBE}.STATUS = 'SUCCESS' AND ${CUBE}.TRANSACTIONTYPE='COLLECTION')` }],
         }
  },
  
  
  dimensions: {
    transactionid: {
      sql: `${CUBE}."TRANSACTIONID"`,
      type: `string`
    },
    
    walletid: {
      sql: `${CUBE}."WALLETID"`,
      type: `string`
    },
    
    operation: {
      sql: `${CUBE}."OPERATION"`,
      type: `string`
    },
    
    transactiontype: {
      sql: `${CUBE}."TRANSACTIONTYPE"`,
      type: `string`
    },
    
    amount: {
      sql: `${CUBE}."AMOUNT"`,
      type: `number`
    },
    
    runningbalance: {
      sql: `${CUBE}."RUNNINGBALANCE"`,
      type: `number`
    },

    fee: {
      sql: `${CUBE}."FEE"`,
      type: `number`
    }, 

    amountbefore: {
      sql: `${CUBE}."AMOUNTBEFORE"`,
      type: `number`
    },

    currency: {
      sql: `${CUBE}."CURRENCY"`,
      type: `string`
    },
    
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    accountfrom: {
      sql: `${CUBE}."ACCOUNTFROM"`,
      type: `string`
    },
    
    accountfromtype: {
      sql: `${CUBE}."ACCOUNTFROMTYPE"`,
      type: `string`
    },
    
    accountto: {
      sql: `${CUBE}."ACCOUNTTO"`,
      type: `string`
    },
    
    accounttotype: {
      sql: `${CUBE}."ACCOUNTTOTYPE"`,
      type: `string`
    },
    
    paymentprovidertransactionid: {
      sql: `${CUBE}."PAYMENTPROVIDERTRANSACTIONID"`,
      type: `string`
    },
    
    paymentprovider: {
      sql: `${CUBE}."PAYMENTPROVIDER"`,
      type: `string`
    },
    
    submerchanttransactionid: {
      sql: `${CUBE}."SUBMERCHANTTRANSACTIONID"`,
      type: `string`
    },
    
    description: {
      sql: `${CUBE}."DESCRIPTION"`,
      type: `string`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },
    
    callback: {
      sql: `${CUBE}."CALLBACK"`,
      type: `string`
    },
    
    paymenttype: {
      sql: `${CUBE}."PAYMENTTYPE"`,
      type: `string`
    },
    
    payeefirstname: {
      sql: `${CUBE}."PAYEEFIRSTNAME"`,
      type: `string`
    },
    
    payeelastname: {
      sql: `${CUBE}."PAYEELASTNAME"`,
      type: `string`
    },
    
    actorcustomerid: {
      sql: `${CUBE}."ACTORCUSTOMERID"`,
      type: `string`
    },
    
    actorcustomername: {
      sql: `${CUBE}."ACTORCUSTOMERNAME"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
