// DESCRIPTION
// This schema used to model transactions history data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 1: Transactions History - a table that contains all transactions made on a specific wallet.


cube(`Wallettransactions`, {
  sql: `SELECT * FROM paymentsdomain_staging.wallettransactions`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
      Walletsinfo: {
      relationship: `belongsTo`,
      sql: `${CUBE}.WALLETID = ${Walletsinfo}.WALLETID`,
    }   
  },
  
  measures: {
    count: {
      sql:`TRANSACTIONID`,
      type: `countDistinct`,
       }
  },
  
  dimensions: {
    walletid: {
      sql: `${CUBE}."WALLETID"`,
      type: `string`,
      primaryKey: true,
      shown: true
    },

    customerid: {
      sql: `${Walletsinfo}."CUSTOMERID"`,
      type: `string`
    },
    
    transactionid: {
      sql: `${CUBE}."TRANSACTIONID"`,
      type: `string`
    },
    
    operation: {
      sql: `${CUBE}."OPERATION"`,
      type: `string`
    },
    
    transactiontype: {
      sql: `${CUBE}."TRANSACTIONTYPE"`,
      type: `string`
    },

    amount: {
      sql: `${CUBE}."AMOUNT"`,
      type: `number`
    },
    
    runningbalance: {
      sql: `${CUBE}."RUNNINGBALANCE"`,
      type: `number`
    },
    
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    accountFrom: {
      sql: `${CUBE}."ACCOUNTFROM"`,
      type: `string`
    },
    
    accountTo: {
      sql: `${CUBE}."ACCOUNTTO"`,
      type: `string`
    },
    
    MoMoID: {
      sql: `${CUBE}."MOMOID"`,
      type: `string`
    },
    
    telco: {
      sql: `${CUBE}."TELCO"`,
      type: `string`
    },
    
    customersTransactionId: {
      sql: `${CUBE}."CUSTOMERSTRANSACTIONID"`,
      type: `string`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },
    
    description: {
      sql: `${CUBE}."DESCRIPTION"`,
      type: `string`
    },
    
    payeefirstname: {
      sql: `${CUBE}."PAYEEFIRSTNAME"`,
      type: `string`
    },
    
    payeelastname: {
      sql: `${CUBE}."PAYEELASTNAME"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
