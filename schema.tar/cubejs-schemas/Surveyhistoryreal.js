// DESCRIPTION
// This schema used to model raw survey-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 19: Survey History - containing a list of surveys and their details.


cube(`Surveyhistoryreal`, {
  sql: `SELECT * FROM ussddomain_staging.surveyhistoryreal`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      //drillMembers: [trackid, surveyid, customerid, surveyname, createdAt, updatedAt, startDate, endDate]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    surveyid: {
      sql: `${CUBE}."SURVEYID"`,
      type: `string`,
      primaryKey: true,
      shown: true,
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },

    appid: {
      sql: `${CUBE}."APPID"`,
      type: `string`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },
    
    eventtype: {
      sql: `${CUBE}."EVENTTYPE"`,
      type: `string`
    },
    
    surveyname: {
      sql: `${CUBE}."SURVEYNAME"`,
      type: `string`
    },
    
    surveydescription: {
      sql: `${CUBE}."SURVEYDESCRIPTION"`,
      type: `string`
    },
    
    primaryShortCode: {
      sql: `${CUBE}."PRIMARYSHORTCODE"`,
      type: `string`
    },
    
    secondaryShortCode: {
      sql: `${CUBE}."SECONDARYSHORTCODE"`,
      type: `string`
    },
    
    createdAt: {
      sql: `${CUBE}."CREATED_AT"`,
      type: `time`
    },
    
    updatedAt: {
      sql: `${CUBE}."UPDATED_AT"`,
      type: `time`
    },
    
    startDate: {
      sql: `${CUBE}."START_DATE"`,
      type: `time`
    },
    
    endDate: {
      sql: `${CUBE}."END_DATE"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});

