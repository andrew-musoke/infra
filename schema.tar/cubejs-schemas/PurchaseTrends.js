// DESCRIPTION
// This schema uses purchase history table to calculate purchases trends by time
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 4: Purchase Trends - describes purchases made per time


cube(`PurchasedTrends`, {
    sql: `SELECT CUSTOMERID, SUM(AMOUNTPAID) AS TOTALPURCHASE, TIME 
    FROM energydomain.purchasehistory
    WHERE STATUS='SUCCESS'
    GROUP BY CUSTOMERID, TIME`,

    
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
      
    },
    
    measures: {

    },
    
    dimensions: {
      
      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },

      totalPurchase: {
        sql: `${CUBE}."TOTALPURCHASE"`,
        type: `number`
      },

      timestamp: {
        sql: `${CUBE}."TIME"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  