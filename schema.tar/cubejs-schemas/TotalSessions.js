// DESCRIPTION
// This schema uses the sessioninforealcube to calculate total number of sessions used use at a given time.

// REQUIREMENT
// Number 7: TotalSessions - contains total number of sessions used use at a given time.

cube(`TotalSessions`, {

  sql: `SELECT * FROM ussddomain_staging.sessioninforeal`,
  

  measures: {
   totalSessions: {
    sql: `SESSIONID`,
    type: 'countDistinct',
  }
  },
  
  dimensions: {   
   timestamp: {
     sql: `${CUBE}."TIME"`,
     type: `time`
   }
  },
  
  dataSource: `default`
  });