// DESCRIPTION
// This schema uses the sessioninforealcube to calculate total number of sessions used use at a given time.

// REQUIREMENT
// Number 7: TotalSessions - contains total number of sessions used use at a given time.

cube(`TotalSessions`, {

    sql: `SELECT COUNT(DISTINCT SESSIONID) AS TOTALSESSIONS, TIME 
         FROM ussddomain.sessioninforeal
         GROUP BY TIME`,

    measures: {
        count: {
          type: `count`,
        }
      },

    dimensions: {  
        totalSessions: {
          sql: `${CUBE}."TOTALSESSIONS"`,
          type: `number`
        },
        
        timestamp: {
          sql: `${CUBE}."TIME"`,
          type: `time`
        }
      },

    dataSource: `default`
  });