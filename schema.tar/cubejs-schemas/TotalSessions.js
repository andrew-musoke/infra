// DESCRIPTION
// This schema uses the sessionhistoryreal to calculate total number of sessions (using the measure) used use at a given time.

// REQUIREMENT
// Number 7: TotalSessions - contains total number of sessions used use at a given time.

  cube(`TotalSessions`, {
    sql: ` SELECT SESSIONID, SERVICECODE, PHONENUMBER, TELCO, APPID, CUSTOMERID, MAX(TIME) AS TIMESTAMP, COUNT(SESSIONID) AS COUNTSESSIONS
           FROM ussddomain.sessionhistoryreal
           GROUP BY SESSIONID, SERVICECODE, PHONENUMBER, TELCO, APPID, CUSTOMERID`,
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  

      main: {
        dimensions: [TotalSessions.sessionid, TotalSessions.servicecode, TotalSessions.phonenumber, TotalSessions.telco, TotalSessions.appid, TotalSessions.appname, TotalSessions.customerid],
        timeDimension: TotalSessions.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [TotalSessions.sessionid, TotalSessions.servicecode, TotalSessions.phonenumber, TotalSessions.telco, TotalSessions.appid, TotalSessions.appname, TotalSessions.customerid] 
          }
        }
      } 
    },
    
    joins: {
      Appinforeal: {
        relationship: `belongsTo`,
        sql: `${CUBE}.APPID = ${Appinforeal}.APPID`,
      },
    },
    
    measures: {
      count: {
        sql:'SESSIONID',
        type: `countDistinct`,
        //drillMembers: [trackid, sessionid, appid]
      }
    },
    
    dimensions: {
     
      sessionid: {
        sql: `${CUBE}."SESSIONID"`,
        type: `string`,
        primaryKey: true,
        shown: true,
      },
      
      servicecode: {
        sql: `${CUBE}."SERVICECODE"`,
        type: `string`
      },
      
      phonenumber: {
        sql: `${CUBE}."PHONENUMBER"`,
        type: `string`
      },
      
      telco: {
        sql: `${CUBE}."TELCO"`,
        type: `string`
      },
      
      appid: {
        sql: `${CUBE}."APPID"`,
        type: `string`,
        primaryKey: true,
        shown: true,
      },
      
      appname: {
        sql: `${Appinforeal}."APPNAME"`,
        type: `string`
      },

      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
  
      timestamp: {
        sql: `${CUBE}."TIMESTAMP"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  