// DESCRIPTION
// This schema uses purchase history table to calculate total Purchases by Telco
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 5: Purchases by Telco - describes purchases made per telco


cube(`PurchasesbyTelco`, {
    sql: `CUSTOMERID, SELECT SUM(AMOUNTPAID) AS TOTALPURCHASE, TELCO 
    FROM energydomain_staging.purchasehistory
    GROUP BY CUSTOMERID, TELCO`,
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
      
    },
    
    measures: {

    },
    
    dimensions: {

      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
        
        
      totalPurchase: {
        sql: `${CUBE}."TOTALPURCHASE"`,
        type: `number`
      },

      telco: {
        sql: `${CUBE}."TELCO"`,
        type: `string`
      }
    },
    
    dataSource: `default`
  });
  