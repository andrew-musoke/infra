// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Sessioninforeal features
// This is done purposely to decouple the Sessions table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 2: Session History - containing a detailed information about a session.

cube(`SessionsMeta`, {
    extends: Sessionmetadatareal,
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      main: {
		    ///measures: [SessionsMeta.count, SessionsMeta.countPhonenumbers],
        dimensions: [SessionsMeta.sessionid, SessionsMeta.servicecode, SessionsMeta.phonenumber, SessionsMeta.telco, SessionsMeta.appid, SessionsMeta.appname, SessionsMeta.sessionduration, SessionsMeta.customerid],
        timeDimension: SessionsMeta.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [SessionsMeta.sessionid, SessionsMeta.servicecode, SessionsMeta.phonenumber, SessionsMeta.telco, SessionsMeta.appid, SessionsMeta.appname, SessionsMeta.sessionduration, SessionsMeta.customerid] 
          }
        }
      }
  
    },

  });