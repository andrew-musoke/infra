// DESCRIPTION
// This schema used to model survey results data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 22: Survey Results - contains a table of surveys and their results.

cube(`SurveyResults`, {

  sql: `
  SELECT qa.SURVEYID, qa.QUESTIONID, qa.ANSWERID, qa.QUESTIONDESCRIPTION, qa.ANSWERDESCRIPTION, 
  IF(SUM(r.COUNTRESPONDENTS)= 0, 0, COUNT(r.PHONENUMBER)) AS TOTALRESPONDENTS, 
  IF(MAX(r.TIMESTAMP) IS NULL, MAX(qa.UPDATEDAT), MAX(qa.UPDATEDAT)) AS TIME
  FROM ussddomain_staging.surveyqnsandanswrs qa
  LEFT JOIN ussddomain_staging.surveyrespondentanswers r
  ON qa.ANSWERID = r.ANSWERID
  GROUP BY qa.SURVEYID, qa.QUESTIONID, qa.ANSWERID, qa.QUESTIONDESCRIPTION, qa.ANSWERDESCRIPTION `,

  joins: {
      
    },
  
    measures: {
      count: {
        type: `count`,
        //drillMembers: [trackid, respondentanswersid, possibleanswersid, timestamp]
      },
  
      totalCount: {
        sql: `${CUBE}.TOTALRESPONDENTS`,
        type: `sum`
      }
    },
    
    dimensions: {
      surveyid: {
        sql: `${CUBE}."SURVEYID"`,
        type: `string`
      },
  
      questionid: {
        sql: `${CUBE}."QUESTIONID"`,
        type: `string`
      },
      
      answerid: {
        sql: `${CUBE}."ANSWERID"`,
        type: `string`,
        primaryKey: true,
        shown: true,
      },
      
      questionDescription: {
        sql: `${CUBE}."QUESTIONDESCRIPTION"`,
        type: `string`
      },
      
      answerDescription: {
        sql: `${CUBE}."ANSWERDESCRIPTION"`,
        type: `string`
      },
  
      totalResponses: {
        sql: `${CUBE}."TOTALRESPONDENTS"`,
        type: `number`
      },
      
      timestamp: {
        sql: `${CUBE}."TIME"`,
        type: `time`
      }
    },
    
    dataSource: `default`

    });


    