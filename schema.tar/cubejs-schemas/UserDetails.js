// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the DubaivisauserinfoDev features
// This is done purposely to decouple the DubaivisauserinfoDev table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 12: Users- Drill Down (i.e. Agent Name, Email, Phone, Branch Name, Town, Country, Creation Date)

cube(`UserDetails`, {
    extends: DubaivisauserinfoDev,
  });