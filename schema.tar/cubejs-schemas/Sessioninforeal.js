// DESCRIPTION
// This schema used to model raw sessions-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 2: Session History - containing a detailed information about a session.

cube(`Sessioninforeal`, {
  sql: `SELECT * FROM ussddomain_staging.sessioninforeal`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [trackid, sessionid, appid]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    sessionid: {
      sql: `${CUBE}."SESSIONID"`,
      type: `string`
    },
    
    servicecode: {
      sql: `${CUBE}."SERVICECODE"`,
      type: `string`
    },
    
    menuitem: {
      sql: `${CUBE}."MENUITEM"`,
      type: `string`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    telco: {
      sql: `${CUBE}."TELCO"`,
      type: `string`
    },

    sequence: {
      sql: `${CUBE}."SEQUENCE"`,
      type: `number`
    },
    
    appid: {
      sql: `${CUBE}."APPID"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
