// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Smsbalancereal features
// This is done purposely to decouple the Smsbalancereal table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 1: SMS balance in client’s wallets

cube(`Smsbalance`, {
    extends: Smsbalancereal,
  });