// DESCRIPTION
// This schema used to model bouncerate data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 8: Bounce Rate - shows the percentage of the single menu item visit divided by all visits.

cube(`Bounceratereal`, {
  sql: `SELECT * FROM ussddomain_staging.bouncerate`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [customerid]
    }
  },
  
  dimensions: {
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },

    bouncerate: {
      sql: `${CUBE}."BOUNCERATE"`,
      type: `number`
    },

    totalsessionsendedatseq1: {
      sql: `${CUBE}."TOTALSESSIONSENDEDATSEQ1"`,
      type: `number`
    },

    totalsessionsended: {
      sql: `${CUBE}."TOTALSESSIONSENDED"`,
      type: `number`
    }

  },
  
  dataSource: `default`
});
