// DESCRIPTION
// This schema used to model raw appinfo data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 3: App Info Table - containing a detailed information about a ussd applications.

cube(`Appinforeal`, {
  sql: `SELECT * FROM ussddomain.appinforeal`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [trackid, customerid, appid, appname, updatedDate, creationDate]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },
    
    appid: {
      sql: `${CUBE}."APPID"`,
      type: `string`
    },
    
    appname: {
      sql: `${CUBE}."APPNAME"`,
      type: `string`
    },

    primaryshortcode: {
      sql: `${CUBE}."PRIMARYSHORTCODE"`,
      type: `number`
    },

    secondaryshortcode: {
      sql: `${CUBE}."SECONDARYSHORTCODE"`,
      type: `number`
    },
    
    url: {
      sql: `${CUBE}."URL"`,
      type: `string`
    },
    
    telcos: {
      sql: `${CUBE}."TELCOS"`,
      type: `string`
    },
    
    type: {
      sql: `${CUBE}."TYPE"`,
      type: `string`
    },
    
    active: {
      sql: `${CUBE}."ACTIVE"`,
      type: `string`
    },
    
    updatedDate: {
      sql: `${CUBE}."UPDATED_DATE"`,
      type: `time`
    },
    
    creationDate: {
      sql: `${CUBE}."CREATION_DATE"`,
      type: `time`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
