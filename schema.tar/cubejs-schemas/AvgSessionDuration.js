// DESCRIPTION
// This schema uses the Maxsessiondurationreal cube to calculate Average Session Duration.

// REQUIREMENT
// Number 6: Average Session Duration- containing information about the average session duration.
  cube(`AvgSessionDuration`, {
    extends: Avgsessiondurationreal
  })