// DESCRIPTION
// This schema uses the Maxsessiondurationreal cube to calculate Average Session Duration.

// REQUIREMENT
// Number 6: Average Session Duration- containing information about the average session duration.
  cube(`AvgSessionDuration`, {
    extends: Avgsessiondurationreal,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      main: {
        measures: [AvgSessionDuration.count, AvgSessionDuration.avgsessionduration],
        dimensions: [AvgSessionDuration.customerid, AvgSessionDuration.sessionid, AvgSessionDuration.sessionduration, AvgSessionDuration.appid],
        timeDimension: AvgSessionDuration.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [AvgSessionDuration.customerid, AvgSessionDuration.sessionid, AvgSessionDuration.sessionduration, AvgSessionDuration.appid] 
          }
        }
      }
  
    },
  })