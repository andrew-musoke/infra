// DESCRIPTION
// This schema uses the Maxsessiondurationreal cube to calculate Average Session Duration.

// REQUIREMENT
// Number 6: Average Session Duration- containing information about the average session duration.


cube(`AvgSessionDuration`, {
    sql: `SELECT * FROM ussddomain_staging.maxsessionduration`,

    
measures: {
        
    avgsessionduration: {
        sql: `${CUBE}."MAX_SESSIONDURATION"`,
        type: `avg`
        }
    },
      
      dataSource: `default`
  });