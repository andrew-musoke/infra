// DESCRIPTION
// This schema used to model raw survey questions and answers data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 21: Survey Questions and Answers - containing a list of all survey questions and answers.
// Number 22: Survey Results - contains a table of surveys and their results.

cube(`Surveyqnsandanswrs`, {
  sql: `SELECT * FROM ussddomain_staging.surveyqnsandanswrs`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {

    Surveyhistoryreal: {
      relationship: `belongsTo`,
      sql: `${CUBE}.SURVEYID = ${Surveyhistoryreal}.SURVEYID`,
    },
    
  },
  
  measures: {
    count: {
      type: `count`,
      //drillMembers: [trackid, surveyid, questionid, answerid, createdat, updatedat]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },

    customerid: {
      sql: `${Surveyhistoryreal}."CUSTOMERID"`,
      type: `string`
    },
    
    surveyid: {
      sql: `${CUBE}."SURVEYID"`,
      type: `string`,
      primaryKey: true,
      shown: true,
    },

    surveyname: {
      sql: `${Surveyhistoryreal}."SURVEYNAME"`,
      type: `string`
    },

    surveydescription: {
      sql: `${Surveyhistoryreal}."SURVEYDESCRIPTION"`,
      type: `string`
    },
    
    questionid: {
      sql: `${CUBE}."QUESTIONID"`,
      type: `string`
    },
    
    questionDescription: {
      sql: `${CUBE}."QUESTIONDESCRIPTION"`,
      type: `string`
    },
    
    answerid: {
      sql: `${CUBE}."ANSWERID"`,
      type: `string`
    },
    
    answerDescription: {
      sql: `${CUBE}."ANSWERDESCRIPTION"`,
      type: `string`
    },

    orderofquestion: {
      sql: `${CUBE}."ORDEROFQN"`,
      type: `number`
    },
    
    orderofanswer: {
      sql: `${CUBE}."ORDEROFANS"`,
      type: `number`
    },
    
    createdat: {
      sql: `${CUBE}."CREATEDAT"`,
      type: `time`
    },
    
    updatedat: {
      sql: `${CUBE}."UPDATEDAT"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
