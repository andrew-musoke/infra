// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Sessioninforeal features
// This is done purposely to decouple the Sessions table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 2: Session History - containing a detailed information about a session.

cube(`Subsessions`, {
    extends: Subsessionsreal
  });