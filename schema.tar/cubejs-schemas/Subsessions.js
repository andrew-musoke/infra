// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Sessioninforeal features
// This is done purposely to decouple the Sessions table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 2: Session History - containing a detailed information about a session.

cube(`Subsessions`, {
    extends: Subsessionsreal,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      main: {
		    //measures:[Subsessions.count],
        dimensions: [Subsessions.sessionid, Subsessions.menuitem, Subsessions.sequence,  Subsessions.tag, Subsessions.chargedamount,  Subsessions.customerid],
        timeDimension: Subsessions.timestamp,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [Subsessions.sessionid, Subsessions.menuitem, Subsessions.sequence,  Subsessions.tag, Subsessions.chargedamount,  Subsessions.customerid] 
          }
        }
      }
  
    },
  });