// DESCRIPTION
// This schema used to model raw balance table data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 4: Sessions Balance Table - contains information about remaining sessions balance in clients wallets.


cube(`Sessionsbalancereal`, {
  sql: `SELECT * FROM ussddomain_staging.sessionsbalancereal`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [trackid, customerid]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },

    balance: {
      sql: `${CUBE}."BALANCE"`,
      type: `number`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
