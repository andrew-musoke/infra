// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Surveyqnsandanswrs features
// This is done purposely to decouple the Surveyqnsandanswrs table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 21: Survey Questions and Answers - containing a list of all survey questions and answers.

cube(`SurveyQA`, {
    extends: Surveyqnsandanswrs,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  

      main: {
        //measures: [SurveyQA.count],
        dimensions: [SurveyQA.customerid, SurveyQA.surveyid, SurveyQA.questionid, SurveyQA.surveyname,  SurveyQA.surveydescription, SurveyQA.questionDescription, SurveyQA.answerid, SurveyQA.answerDescription],
        timeDimension: SurveyQA.createdat,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [SurveyQA.customerid, SurveyQA.surveyid, SurveyQA.questionid, SurveyQA.surveyname,  SurveyQA.surveydescription, SurveyQA.questionDescription, SurveyQA.answerid, SurveyQA.answerDescription] 
          }
        }
      }
    },
  });