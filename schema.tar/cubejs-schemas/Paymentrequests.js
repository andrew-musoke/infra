// DESCRIPTION
// This schema used to show a list of payment requests data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 10: Payment Requests - contains a list of all payment requests made to the wallet.


cube(`Paymentrequests`, {
  sql: `SELECT * FROM paymentsdomain.paymentrequests`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `countDistinct`,
      sql: `${CUBE}."TRACKID"`,
      //drillMembers: [trackid, merchanttransactionid, actorcustomerid]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    merchanttransactionid: {
      sql: `${CUBE}."MERCHANTTRANSACTIONID"`,
      type: `string`
    },

    totalamount: {
      sql: `${CUBE}."TOTALAMOUNT"`,
      type: `number`
    },

    totalbeneficiaries: {
      sql: `${CUBE}."TOTALBENEFICIARIES"`,
      type: `number`
    },
    
    paymentdescription: {
      sql: `${CUBE}."PAYMENTDESCRIPTION"`,
      type: `string`
    },
    
    actorcustomerid: {
      sql: `${CUBE}."ACTORCUSTOMERID"`,
      type: `string`
    },
    
    status: {
      sql: `${CUBE}."STATUS"`,
      type: `string`
    },
    
    statusdescription: {
      sql: `${CUBE}."STATUSDESCRIPTION"`,
      type: `string`
    },
    
    eventtype: {
      sql: `${CUBE}."EVENTTYPE"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
