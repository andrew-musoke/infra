// DESCRIPTION
// This schema is used to find the ratio of new to returning visitors
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 17: New vs Returning Visitors - shows the ratio of the new vs returning visitors, represented best in a pie chart


cube(`NewvsReturningVisitors`, {

    sql: `SELECT CUSTOMERID,
           CASE WHEN COUNTPHONENUMBERS = 1 THEN COUNT(COUNTPHONENUMBERS) ELSE COUNT(COUNTPHONENUMBERS) END AS VISITORS,
           CASE WHEN COUNTPHONENUMBERS = 1 THEN 'New' ELSE 'Returning' END AS LABEL, TIMESTAMP
           FROM 
              (SELECT CUSTOMERID, PHONENUMBER, MAX(TIME) AS TIMESTAMP, COUNT(PHONENUMBER) AS COUNTPHONENUMBERS
               FROM ussddomain_staging.sessionhistoryreal
               GROUP BY CUSTOMERID, PHONENUMBER) sub
           GROUP BY CUSTOMERID, COUNTPHONENUMBERS, TIMESTAMP `,
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
      
    },
    
    measures: {
      count: {
        type: `count`,
        //drillMembers: [trackid, sessionid, customerid, appid]
      },

      visitors: {
        sql: `${CUBE}."VISITORS"`,
        type: `sum`
      },
    },
    
    dimensions: {
      
      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
      
      label: {
        sql: `${CUBE}."LABEL"`,
        type: `string`
      },
      
      timestamp: {
        sql: `${CUBE}."TIMESTAMP"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  