// DESCRIPTION
// This schema used to model raw session-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 2: Session History - containing a detailed information about a session.

cube(`Subsessionsreal`, {
    sql: `SELECT * FROM ussddomain_staging.sessioninforealnew`,
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
        Chargedsessionsreal: {
        relationship: `belongsTo`,
        sql: `${CUBE}.SESSIONID = ${Chargedsessionsreal}.SESSIONID AND ${CUBE}.SEQUENCE = ${Chargedsessionsreal}.SEQUENCE`,
      }, 
    },
    
    measures: {
      count: {
        sql:'SESSIONID',
        type: `countDistinct`,
        //drillMembers: [trackid, sessionid, appid]
      }
    },
    
    dimensions: {

      sessionid: {
        sql: `${CUBE}."SESSIONID"`,
        type: `string`,
        primaryKey: true,
        shown: true,
      },
      
      menuitem: {
        sql: `${CUBE}."MENUITEM"`,
        type: `string`
      },
  
      sequence: {
        sql: `${CUBE}."SEQUENCE"`,
        type: `number`,
        primaryKey: true,
        shown: true
      },

      tag: {
        sql: `${CUBE}."TAG"`,
        type: `string`
      },

      chargedamount: {
        sql: `${Chargedsessionsreal}."CHARGEDAMOUNT"`,
        type: `number`
      },

      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
  
      timestamp: {
        sql: `${CUBE}."TIME"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  
  
  
  
  
  