// DESCRIPTION
// This schema used to model user details data from the clickhouse database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for the front end appications

// REQUIREMENT
// Number 12: Users- Drill Down (i.e. Agent Name, Email, Phone, Branch Name, Town, Country, Creation Date)

cube(`DubaivisauserinfoDev`, {
  sql: `SELECT * FROM dubaivisadomain_dev.dubaivisauserinfo_dev`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [userid, firstname, lastname, username, branchname, createdAt]
    }
  },
  
  dimensions: {
    userid: {
      sql: `${CUBE}."USERID"`,
      type: `string`
    },
    
    firstname: {
      sql: `${CUBE}."FIRSTNAME"`,
      type: `string`
    },
    
    lastname: {
      sql: `${CUBE}."LASTNAME"`,
      type: `string`
    },
    
    username: {
      sql: `${CUBE}."USERNAME"`,
      type: `string`
    },
    
    email: {
      sql: `${CUBE}."EMAIL"`,
      type: `string`
    },
    
    role: {
      sql: `${CUBE}."ROLE"`,
      type: `string`
    },
    
    branchname: {
      sql: `${CUBE}."BRANCHNAME"`,
      type: `string`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    createdAt: {
      sql: `${CUBE}."CREATED_AT"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
