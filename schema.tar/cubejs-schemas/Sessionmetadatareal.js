// DESCRIPTION
// This schema used to model raw session-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 2: Session History - containing a detailed information about a session.
// Number 14: Number of sessions per visitor - contains the average number of sessions per visitors

cube(`Sessionmetadatareal`, {
    sql: ` SELECT SESSIONID, SERVICECODE, PHONENUMBER, TELCO, APPID, CUSTOMERID, MAX(TIME) AS TIMESTAMP, COUNT(SESSIONID) AS COUNTSESSIONS
           FROM ussddomain_staging.sessionhistoryreal
           GROUP BY SESSIONID, SERVICECODE, PHONENUMBER, TELCO, APPID, CUSTOMERID`,
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
      Appinforeal: {
        relationship: `belongsTo`,
        sql: `${CUBE}.APPID = ${Appinforeal}.APPID`,
      },

      Avgsessiondurationreal: {
        relationship: `belongsTo`,
        sql: `${CUBE}.SESSIONID = ${Avgsessiondurationreal}.SESSION_ID`,
      },
    },
    
    measures: {
      // these measure calculates total number of sessions
      count: {
        sql:'SESSIONID',
        type: `countDistinct`,
       
      },

      // these measure calculates total number of distinct users/visitors
      countPhonenumbers: {
        sql:`PHONENUMBER`,
        type: `countDistinct`,
      },
      
      // these measure divided the two measures above to calculate the total number of distinct sessions per total number of visitors
      numberofSessionsperVisitors:{
        sql: `${CUBE.count} / ${CUBE.countPhonenumbers}`,
        type: `number`,
      },

    },
    
    dimensions: {
     
      sessionid: {
        sql: `${CUBE}."SESSIONID"`,
        type: `string`,
        primaryKey: true,
        shown: true,
      },
      
      servicecode: {
        sql: `${CUBE}."SERVICECODE"`,
        type: `string`
      },
      
      phonenumber: {
        sql: `${CUBE}."PHONENUMBER"`,
        type: `string`
      },
      
      telco: {
        sql: `${CUBE}."TELCO"`,
        type: `string`
      },
      
      appid: {
        sql: `${CUBE}."APPID"`,
        type: `string`,
        primaryKey: true,
        shown: true,
      },
      
      appname: {
        sql: `${Appinforeal}."APPNAME"`,
        type: `string`
      },

      sessionduration: {
        sql: `${Avgsessiondurationreal}."MAX_SESSIONDURATION"`,
        type: `number`
      },

      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
  
      timestamp: {
        sql: `${CUBE}."TIMESTAMP"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  
  
  
  
  
  