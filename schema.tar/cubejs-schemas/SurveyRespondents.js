// DESCRIPTION
// This schema used to create survey respondents details.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 23: Survey Respondents Details - contains the details of the respondents (e.g. phonenumber, answer, question, time)

cube(`SurveyRespondents`, {
    extends: Surveyrespondentanswers
  });