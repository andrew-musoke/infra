// DESCRIPTION
// This schema used to get Total Payouts & Collections  data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 5: Total Payouts & Collections - a big number showing the total amount of Payouts & Collections made on a wallet.


cube(`TotalCollectionPayouts`, {

    sql: `
          SELECT WALLETID, SUM(AMOUNT) AS TOTALCOLLECTIONPAYOUTS, TIMESTAMP
          FROM paymentsdomain_staging.wallettransactions
          WHERE (TRANSACTIONTYPE='COLLECTION' OR TRANSACTIONTYPE='PAYOUT') AND STATUS='SUCCESS' 
          GROUP BY  WALLETID, TIMESTAMP
          `,
         
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
        Walletsinfo: {
        relationship: `belongsTo`,
        sql: `${CUBE}.WALLETID = ${Walletsinfo}.WALLETID`,
      }   
    },
    
    measures: {
      count: {
        type: `count`,
         },
   
      totalcollectionpayoutsNumber: {
          sql:`TOTALCOLLECTIONPAYOUTS`,
          type: `sum`,
           },
  
    },
    
    dimensions: {
      walletid: {
        sql: `${CUBE}."WALLETID"`,
        type: `string`,
        primaryKey: true,
        shown: true
      },
  
      customerid: {
        sql: `${Walletsinfo}."CUSTOMERID"`,
        type: `string`
      },
  
      amount: {
        sql: `${CUBE}."TOTALCOLLECTIONPAYOUTS"`,
        type: `number`
      },
      
      timestamp: {
        sql: `${CUBE}."TIMESTAMP"`,
        type: `time`
      }
    },
    
    dataSource: `default`
  });
  