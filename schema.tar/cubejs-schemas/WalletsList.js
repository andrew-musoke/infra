// DESCRIPTION
// This schema used to show a list of all wallets from the database into meaningful business insights.
// This schema extends "Walletsinfo" schema to allow a reuse of some relevant dimensions.

// REQUIREMENT
// Number 9: Wallets Lists - contains a list of all wallets and their basic information (walletname, customername, date of creation & update, etc.)

cube(`WalletsList`, {
    extends: Walletsinfo,

    dimensions: {
        walletid: {
          sql: `${CUBE}."WALLETID"`,
          type: `string`,
          primaryKey: true,
          shown: true
        },
        
        customerid: {
          sql: `${CUBE}."CUSTOMERID"`,
          type: `string`
        },
        
        walletname: {
          sql: `${CUBE}."LABEL"`,
          type: `string`
        },
        
        customername: {
          sql: `${CUBE}."CUSTOMERNAME"`,
          type: `string`
        },
        
        createdat: {
          sql: `${CUBE}."CREATED_AT"`,
          type: `time`
        },
        
        updatedat: {
          sql: `${CUBE}."UPDATED_AT"`,
          type: `time`
        }
      },
  });