// DESCRIPTION
// This schema used to show a list of all wallets from the database into meaningful business insights.
// This schema extends "Walletsinfo" schema to allow a reuse of some relevant dimensions.

// REQUIREMENT
// Number 9: Wallets Lists - contains a list of all wallets and their basic information (walletname, customername, date of creation & update, etc.)

cube(`WalletsList`, {

    sql: `SELECT DISTINCT WALLETID, CUSTOMERID AS MERCHANTID, LABEL, CUSTOMERNAME AS MERCHANTNAME, CREATED_AT, UPDATED_AT 
        FROM paymentsdomain.walletsinfo`,

    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  
      main: {
        dimensions: [WalletsList.walletid, WalletsList.merchantid, WalletsList.label, WalletsList.merchantname,WalletsList.createdat],
        timeDimension: WalletsList.updatedat,
        granularity: `day`,
        indexes: {
          categoryIndex: {
           columns: [WalletsList.walletid, WalletsList.merchantid, WalletsList.label, WalletsList.merchantname, WalletsList.createdat] 
          }
        }
      }
    },

    dimensions: {
        walletid: {
          sql: `${CUBE}."WALLETID"`,
          type: `string`,
          primaryKey: true,
          shown: true
        },
        
        merchantid: {
          sql: `${CUBE}."CUSTOMERID"`,
          type: `string`
        },
        
        label: {
          sql: `${CUBE}."LABEL"`,
          type: `string`
        },
        
        merchantname: {
          sql: `${CUBE}."CUSTOMERNAME"`,
          type: `string`
        },
        
        createdat: {
          sql: `${CUBE}."CREATED_AT"`,
          type: `time`
        },
        
        updatedat: {
          sql: `${CUBE}."UPDATED_AT"`,
          type: `time`
        }
      },
  });