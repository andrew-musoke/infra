// DESCRIPTION
// This schema used to model raw session-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 13: UniqueVisitors (Number, Trends, Contacts) - containing information about the number, trends unique UniqueVisitors and their contacts (phonenumbers).


cube(`UniqueVisitors`, {  
    
      sql: `SELECT CUSTOMERID, APPID, PHONENUMBER, MAX(TIME) AS TIMESTAMP, COUNT(DISTINCT PHONENUMBER) AS COUNTPHONENUMBERS
            FROM ussddomain_staging.sessionhistoryreal
            GROUP BY CUSTOMERID, APPID, PHONENUMBER`,
            
      
      preAggregations: {
        // Pre-Aggregations definitions go here
        // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started 
        
        main: {
          measures: [UniqueVisitors.count],
          dimensions: [UniqueVisitors.customerid, UniqueVisitors.appid, UniqueVisitors.phonenumber, UniqueVisitors.countphonenumbers],
          timeDimension: UniqueVisitors.timestamp,
          granularity: `day`,
          indexes: {
            categoryIndex: {
             columns: [UniqueVisitors.customerid, UniqueVisitors.appid, UniqueVisitors.phonenumber, UniqueVisitors.countphonenumbers] 
            }
          }
        }
      },
      
      joins: {
        
      },
      
      measures: {
        count: {
          type: `count`,
        }
      },
      
      dimensions: {
        customerid: {
          sql: `${CUBE}."CUSTOMERID"`,
          type: `string`
        },
  
        appid: {
          sql: `${CUBE}."APPID"`,
          type: `string`
        },
    
        phonenumber: {
          sql: `${CUBE}."PHONENUMBER"`,
          type: `number`
        },
    
        countphonenumbers: {
          sql: `${CUBE}."COUNTPHONENUMBERS"`,
          type: `number`
        },
  
        timestamp: {
          sql: `${CUBE}."TIMESTAMP"`,
          type: `time`
        }
    
      },
      
      dataSource: `default`
    });
    