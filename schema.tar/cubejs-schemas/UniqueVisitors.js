// DESCRIPTION
// This schema used to model raw session-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 13: Unique Visitors (Number, Trends, Contacts) - containing information about the number, trends unique visitors and their contacts (phonenumbers).

// DESCRIPTION
// This schema used to model raw session-history data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 2: Session History - containing a detailed information about a session.


cube(`UniqueVisitors`, {
  sql: `SELECT * FROM ussddomain_staging.sessionhistoryreal`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
        sql:`PHONENUMBER`,
        type: `countDistinct`
      },

      //this time, will be the latest time the countDistinct value was picked
      time: {
        sql:`TIME`,
        type: `max`
      }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    sessionid: {
      sql: `${CUBE}."SESSIONID"`,
      type: `string`
    },
    
    servicecode: {
      sql: `${CUBE}."SERVICECODE"`,
      type: `string`
    },
    
    menuitem: {
      sql: `${CUBE}."MENUITEM"`,
      type: `string`
    },
    
    action: {
      sql: `${CUBE}."ACTION"`,
      type: `string`
    },
    
    tag: {
      sql: `${CUBE}."TAG"`,
      type: `string`
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    telco: {
      sql: `${CUBE}."TELCO"`,
      type: `string`
    },
    
    appid: {
      sql: `${CUBE}."APPID"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIME"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});

  