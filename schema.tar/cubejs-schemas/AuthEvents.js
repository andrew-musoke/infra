// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the UssdAuthreal features
// This is done purposely to decouple the AuthEvents table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 6: Auth Events Table - containing information about authorization events in the BaseUSSD application.

cube(`AuthEvents`, {
    extends: UssdAuthreal
  });