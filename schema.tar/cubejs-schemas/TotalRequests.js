// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the dubaivisarevenueperbranches_dev features
// This is done purposely to decouple the dubaivisarevenueperbranches_dev table to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 1: Total number of visa applications

cube(`TotalRequests`, {
    extends: DubaivisatotalrequestsDev,
  });