// DESCRIPTION
// This schema used to show Payouts data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 3: Total Payouts - a big number showing the total amount of Payouts made on a wallet.
// Number 6: Payout Trends - a line chart trend showing payouts per specific time.

cube(`TotalPayouts`, {

  sql: `
        SELECT WALLETID, SUM(AMOUNT) AS TOTALPAYOUTS, TIMESTAMP
        FROM paymentsdomain_staging.wallettransactions
        WHERE TRANSACTIONTYPE='PAYOUT' AND STATUS='SUCCESS' 
        GROUP BY  WALLETID, TIMESTAMP
        `,
       
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
      Walletsinfo: {
      relationship: `belongsTo`,
      sql: `${CUBE}.WALLETID = ${Walletsinfo}.WALLETID`,
    }   
  },
  
  measures: {
    count: {
      type: `count`,
       },
 
    totalpayoutsNumber: {
        sql:`TOTALPAYOUTS`,
        type: `sum`,
         },

  },
  
  dimensions: {
    walletid: {
      sql: `${CUBE}."WALLETID"`,
      type: `string`,
      primaryKey: true,
      shown: true
    },

    customerid: {
      sql: `${Walletsinfo}."CUSTOMERID"`,
      type: `string`
    },

    amount: {
      sql: `${CUBE}."TOTALPAYOUTS"`,
      type: `number`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
