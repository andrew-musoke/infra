// DESCRIPTION
// This schema uses purchase history table to calculate most frequent purchases
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

//REQUIREMENT
//Number 3: Frequently Purchased Amount - describes the amount (in RWF) that was most frequently purchased

cube(`FrequentlyPurchasedAmt`, {
    sql: `SELECT CUSTOMERID, AMOUNTPAID, COUNT(AMOUNTPAID) AS VALUE_OCCURENCE 
    FROM energydomain.purchasehistory
    GROUP BY CUSTOMERID, AMOUNTPAID
    ORDER BY VALUE_OCCURENCE DESC
    LIMIT 1`,
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
      
    },
    
    measures: {

    },
    
    dimensions: {

      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
        
      amount: {
        sql: `${CUBE}."AMOUNTPAID"`,
        type: `number`
      }
    },
    
    
    dataSource: `default`
  });
  