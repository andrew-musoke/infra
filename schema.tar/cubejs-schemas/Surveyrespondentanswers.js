// DESCRIPTION
// This schema used to model survey results data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 22: Survey Results - contains a table of surveys and their results.

cube(`Surveyrespondentanswers`, {
  sql: `SELECT * FROM ussddomain_staging.surveyrespondentanswers`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [trackid, respondentanswersid, possibleanswersid, timestamp]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    respondentanswersid: {
      sql: `${CUBE}."RESPONDENTANSWERSID"`,
      type: `string`
    },
    
    possibleanswersid: {
      sql: `${CUBE}."POSSIBLEANSWERSID"`,
      type: `string`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    eventtype: {
      sql: `${CUBE}."EVENTTYPE"`,
      type: `string`
    },

    responses: {
      sql: `${CUBE}."COUNTRESPONDENTS"`,
      type: `number`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
