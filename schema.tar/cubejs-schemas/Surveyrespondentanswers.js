// DESCRIPTION
// This schema used to model survey results data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 22: Survey Results - contains a table of surveys and their results.
// Number 23: Survey Respondents Details - contains the details of the respondents (e.g. phonenumber, answer, question, time)

cube(`Surveyrespondentanswers`, {
  sql: `SELECT * FROM ussddomain.surveyrespondentanswers`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    Surveyqnsandanswrs: {
      relationship: `belongsTo`,
      sql: `${CUBE}.ANSWERID = ${Surveyqnsandanswrs}.ANSWERID`,
    },
    
    Surveyhistoryreal: {
      relationship: `belongsTo`,
      sql: `${CUBE}.SURVEYID = ${Surveyhistoryreal}.SURVEYID`,
    },
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [trackid, surveyid, questionid, answerid, timestamp]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },

    customerid: {
     sql: `${Surveyhistoryreal}."CUSTOMERID"`,
     type: `string`
   },
    
    surveyid: {
      sql: `${CUBE}."SURVEYID"`,
      type: `string`,
      primaryKey: true,
      shown: true,
    },

    surveyname: {
      sql: `${Surveyhistoryreal}."SURVEYNAME"`,
      type: `string`
    },
    
    questionid: {
      sql: `${CUBE}."QUESTIONID"`,
      type: `string`
    },

    questionDescription: {
      sql: `${Surveyqnsandanswrs}."QUESTIONDESCRIPTION"`,
      type: `string`
    },
    
    answerid: {
      sql: `${CUBE}."ANSWERID"`,
      type: `string`
    },

    answerDescription: {
      sql: `${Surveyqnsandanswrs}."ANSWERDESCRIPTION"`,
      type: `string`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    eventtype: {
      sql: `${CUBE}."EVENTTYPE"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});

