// DESCRIPTION
// This schema used to model survey results data from the database into meaningful business definition.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 22: Survey Results - contains a table of surveys and their results.

cube(`Surveyrespondentanswers`, {
  sql: `SELECT * FROM ussddomain_staging.surveyrespondentanswers`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      //drillMembers: [trackid, surveyid, questionid, answerid, timestamp]
    }
  },
  
  dimensions: {
    trackid: {
      sql: `${CUBE}."TRACKID"`,
      type: `string`
    },
    
    surveyid: {
      sql: `${CUBE}."SURVEYID"`,
      type: `string`
    },
    
    questionid: {
      sql: `${CUBE}."QUESTIONID"`,
      type: `string`
    },
    
    answerid: {
      sql: `${CUBE}."ANSWERID"`,
      type: `string`
    },
    
    phonenumber: {
      sql: `${CUBE}."PHONENUMBER"`,
      type: `string`
    },
    
    eventtype: {
      sql: `${CUBE}."EVENTTYPE"`,
      type: `string`
    },
    
    timestamp: {
      sql: `${CUBE}."TIMESTAMP"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});

