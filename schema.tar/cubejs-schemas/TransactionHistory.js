// DESCRIPTION
// This schema uses the cubejs extends parameter to reuse all the Wallettransactions features
// This is done purposely to decouple the Wallettransactions stream to increase its flexilibity for it to be used in the querying API

// REQUIREMENT
// Number 1: Transactions History - a table that contains all transactions made on a specific wallet.
// Number 3: Total Payouts - a big number showing the total amount of Payouts made on a wallet.
// Number 6: Payout Trends - a line chart trend showing payouts per specific time.
// Number 4: Total Collections - a big number showing the total amount of Collections made on a wallet.
// Number 7: Collections Trends - a line chart trend showing collections per specific time.
// Number 5: Total Payouts & Collections - a big number showing the total amount of Payouts & Collections made on a wallet.
// Number 11: Bulk transactions - contains a list of all bulk transactions processed by the wallet.

cube(`TransactionHistory`, {
    extends: Wallettransactions,
  });