// DESCRIPTION
// This schema used to model wallet's current balance data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 2: Wallet's current balance - a big number showing wallet's current balance.


cube(`Walletsinfo`, {
  sql: `SELECT * FROM paymentsdomain_staging.walletsinfo`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      //drillMembers: [walletid, customerid, customername, currencyid, createdAt, updatedAt]
    },
    
    
  },
  
  dimensions: {
    walletid: {
      sql: `${CUBE}."WALLETID"`,
      type: `string`,
      primaryKey: true,
      shown: true
    },
    
    customerid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },

    actualbalance: {
      sql: `${CUBE}."ACTUALBALANCE"`,
      type: `number`
    },
    
    amount: {
      sql: `${CUBE}."AVAILABLEBALANCE"`,
      type: `number`
    },
    
    label: {
      sql: `${CUBE}."LABEL"`,
      type: `string`
    },
    
    customername: {
      sql: `${CUBE}."CUSTOMERNAME"`,
      type: `string`
    },
    
    eventtype: {
      sql: `${CUBE}."EVENTTYPE"`,
      type: `string`
    },
    
    currencyid: {
      sql: `${CUBE}."CURRENCYID"`,
      type: `string`
    },
    
    createdAt: {
      sql: `${CUBE}."CREATED_AT"`,
      type: `time`
    },
    
    updatedAt: {
      sql: `${CUBE}."UPDATED_AT"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
