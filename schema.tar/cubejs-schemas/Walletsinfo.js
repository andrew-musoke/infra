// DESCRIPTION
// This schema used to model wallet's current balance data from the database into meaningful business insights.
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 2: Wallet's current balance - a big number showing wallet's current balance.
// Number 9: Wallets Lists - contains a list of all wallets and their basic information (walletname, customername, date of creation & update, etc.)


cube(`Walletsinfo`, {
  sql: `SELECT * FROM paymentsdomain.walletsinfo`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    
  },
  
  measures: {
    count: {
      type: `count`,
      //drillMembers: [walletid, customerid, customername, currencyid, createdAt, updatedAt]
    }
  },
  
  dimensions: {
    walletid: {
      sql: `${CUBE}."WALLETID"`,
      type: `string`,
      primaryKey: true,
      shown: true
    },
    
    merchantid: {
      sql: `${CUBE}."CUSTOMERID"`,
      type: `string`
    },
    
    label: {
      sql: `${CUBE}."LABEL"`,
      type: `string`
    },

    actualbalance: {
      sql: `${CUBE}."ACTUALBALANCE"`,
      type: `number`
    },
    
    availablebalance: {
      sql: `${CUBE}."AVAILABLEBALANCE"`,
      type: `number`
    },
    
    merchantname: {
      sql: `${CUBE}."CUSTOMERNAME"`,
      type: `string`
    },
    
    eventtype: {
      sql: `${CUBE}."EVENTTYPE"`,
      type: `string`
    },
    
    currencyid: {
      sql: `${CUBE}."CURRENCYID"`,
      type: `string`
    },
    
    createdat: {
      sql: `${CUBE}."CREATED_AT"`,
      type: `time`
    },
    
    updatedat: {
      sql: `${CUBE}."UPDATED_AT"`,
      type: `time`
    }
  },
  
  dataSource: `default`
});
