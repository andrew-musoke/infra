// DESCRIPTION
// This schema uses purchase history table to calculate Frequently Purchased Amount
// This schema will the be exposed through cubejs querying API to allow end-users to query data for their front end appications

// REQUIREMENT
// Number 6: Frequently Purchased Amount - describes the success rates of a purchase made


cube(`PurchaseSuccessRates`, {
    sql: `SELECT CUSTOMERID, COUNT(STATUS) AS STATUSCOUNT, STATUS 
    FROM energydomain.purchasehistory
    GROUP BY CUSTOMERID, STATUS`,
    
    preAggregations: {
      // Pre-Aggregations definitions go here
      // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
    },
    
    joins: {
      
    },
    
    measures: {

    },
    
    dimensions: {

      customerid: {
        sql: `${CUBE}."CUSTOMERID"`,
        type: `string`
      },
        
      statusCount: {
        sql: `${CUBE}."STATUSCOUNT"`,
        type: `number`
      },

      status: {
        sql: `${CUBE}."STATUS"`,
        type: `string`
      }
    },
    
    dataSource: `default`
  });
  