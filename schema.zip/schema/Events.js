cube(`Events`, {
    extends: Basesmsauthreal,
  });