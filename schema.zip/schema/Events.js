cube(`Events`, {
    extends: Basesmsauthrealv1,
  });