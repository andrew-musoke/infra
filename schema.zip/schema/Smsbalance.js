cube(`Smsbalance`, {
    extends: Smsbalancerealv1,
  });