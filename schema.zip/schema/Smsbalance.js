cube(`Smsbalance`, {
    extends: Smsbalancereal,
  });