cube(`CampaignHistory`, {
    extends: Campaignhistoryreal,
  });