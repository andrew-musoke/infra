cube(`CampaignHistory`, {
    extends: Campaigndetails,
  });