cube(`PurchaseHistory`, {
    extends: Purchasehistoryreal,
  });