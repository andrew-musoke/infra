cube(`CampaignReport`, {
    extends: Campaignreportreal,
  });